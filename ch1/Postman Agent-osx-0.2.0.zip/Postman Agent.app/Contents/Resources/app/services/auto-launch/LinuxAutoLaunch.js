const path = require('path'),
  os = require('os'),
  AutoLaunch = require('./AutoLaunch'),
  fs = require('fs'),
  autoStartDir = `${os.homedir}/.config/autostart`, // the directory where the desktop files with auto start configuration lives
  desktopFilePathForAutoLaunch = `${autoStartDir}/${pm.config.get('AppName')}.desktop`; // the path for auto launch desktop file

  /**
   * @description Using the symbolic link as binary path to be consistent across updates
   * @param {String} appFolder The folder of the binary which created this process
   * @returns {String} the binary path of the App
   */
  function getAppBinaryPath (appFolder) {
    return path.resolve(appFolder, '..', pm.config.get('AppName'));
  }

  /**
   * @description Gets the contents of the linux desktop file for auto launch
   * @param {String} appBinaryPath the binary path of the App
   * @returns {String}
   */
  function getDesktopEntry (appFolder) {
    return `[Desktop Entry]
Name=${pm.config.get('AppName')}
Exec=${getAppBinaryPath(appFolder)}
Type=Application
Categories=GNOME;GTK;Network;`;
  }

/**
 * Class implementing auto launch for Linux
 * @class
 * @implements {AutoLaunch}
 * To auto launch deskop app on OS Login,
 *   1.Create a .desktop file with the executable path and Icon path.
 *   2.Create autostart folder under ~/.config folder if not present.
 *   3.Create a symbolic link to the .desktop file under autostart folder.
 */
class LinuxAutoLaunch extends AutoLaunch {
  constructor () {
    super();
    this._isInitiallyEnabled = false;
  }

  /**
   * Should be called when the app is ready as we try to refresh the tray menu GUI after enabling
   * @override
   */
  initialize () {
    // Check if desktop file exists and refresh the tray menu item
    fs.access(desktopFilePathForAutoLaunch, fs.constants.F_OK, (err) => {
      this._isInitiallyEnabled = (err) ? false : true;

      // Using inline require to avoid cyclic dependency
      require('../../src/menu').MenuManager.refreshAutoLaunchMenuItem();
    });
  }

  /**
   * Check if the auto launch is set
   * @override
   */
  isEnabled () {
    return this._isInitiallyEnabled;
  }

  /**
   * Auto launch preference in Linux can be modified if the app symlink is available.
   * @param {Callback} cb call back with boolean parameter.
   * @override
   */
  _canModifyAutoLaunch (cb) {
    if (this._isDevMode) {
      pm.logger.info('AutoLaunch: Disabled in developer mode');
      cb(false);
      return;
    }

    const appBinaryPath = getAppBinaryPath(this._appFolder);

    // In case of symlink being deleted. Auto launch uses symlink as symlink path stays the same across updates.
    fs.access(appBinaryPath, fs.constants.F_OK, (err) => {
      if (err) {
        pm.logger.error(`AutoLaunch: Missing ${pm.config.get('AppName')}, checked: `, appBinaryPath);
        cb(false);
        return;
      }

      cb(true);
    });
  }

  /**
   * Enables auto launch by creating a desktop file at auto start directory
   * @override
   */
  enable () {
    this._canModifyAutoLaunch((mutable) => {
      if (mutable) {
        fs.mkdir(autoStartDir, { recursive: true }, (err) => {
          if (err) {
            pm.logger.error('AutoLaunch: Failed to create autostart directory.', err);
            return;
          }

          fs.writeFile(desktopFilePathForAutoLaunch, getDesktopEntry(this._appFolder), (err) => {
            if (err) {
              pm.logger.error('AutoLaunch: Failed to create autostart desktop file.', err);
              return;
            }

            this._isInitiallyEnabled = true;
            pm.logger.info('AutoLaunch: Enabled');
          });
        });
        return;
      }
      pm.logger.error('AutoLaunch: Not modifiable.');
    });
  }

  /**
   * Disables auto launch by removing the desktop file from auto start directory
   * @override
   */
  disable () {
    this._canModifyAutoLaunch((mutable) => {
      if (mutable) {
        fs.access(desktopFilePathForAutoLaunch, fs.constants.F_OK, (err) => {
          if (err) {
            pm.logger.info('AutoLaunch: Already Disabled.');
            return;
          }

          fs.unlink(desktopFilePathForAutoLaunch, (err) => {
            if (err) {
              pm.logger.error('AutoLaunch: Failed to delete autostart desktop file.', err);
              return;
            }

            this._isInitiallyEnabled = false;
            pm.logger.info('AutoLaunch: Disabled');
          });
        });
        return;
      }
      pm.logger.error('AutoLaunch: Not modifiable.');
    });
  }

}

module.exports = LinuxAutoLaunch;
